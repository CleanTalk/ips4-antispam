//<?php

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
    exit;
}
require_once(\IPS\Application::getRootPath().'/applications/antispambycleantalk/sources/autoload.php');

use Cleantalk\Antispam\Cleantalk;
use Cleantalk\Antispam\CleantalkRequest;
use Cleantalk\Antispam\CleantalkResponse;
use Cleantalk\Common\Helper as CleantalkHelper;

abstract class antispambycleantalk_hook_add_topic extends _HOOK_CLASS_
{
	/**
	 * Add Topic
	 *
	 * @return    void
	 */
	protected function add()
	{
		var_dump('test');die;
	}
}
