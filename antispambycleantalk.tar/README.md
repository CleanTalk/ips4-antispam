# ips4-antispam
IPS Community Suite 4.2+ (IP.Board) anti-spam extension.
https://invisioncommunity.com/files/file/9760-antispam-by-cleantalk/
# Version 2.2.1