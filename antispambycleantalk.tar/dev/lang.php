<?php

$lang = array(
	'__app_antispambycleantalk'	=> "Antispam by Cleantalk",
    'ct_contact_form_check' => 'Protect contact form',
    'ct_moderate_new' => 'Moderate new users posts',
    'ct_access_key' => 'Access key',
    'ct_posts_to_check' => 'Do not check users with posts more than',
    'ct_show_link' => 'Show link to CleanTalk',
    'ct_cleantalk_sfw' => 'Enable SpamFireWall',
    'ct_spam_check' => 'Check spam users via members list',
    'antispambycleantalk_settings' => 'Antispam by Cleantalk Settings',
    'menu__antispambycleantalk_antispambycleantalk' => 'Antispam by Cleantalk',
    'menu__antispambycleantalk_antispambycleantalk_settings' => 'Settings',
    'dashboard_key_is_empty_description' => 'Please enter Access Key in Anti-Spam by CleanTalk settings to enable anti spam protection!',
    'go_to_settings' => 'Settings',
);
